import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,ModalController } from 'ionic-angular';
import { SettingsPage } from '../settings/settings';

/**
 * Generated class for the MinePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-mine',
  templateUrl: 'mine.html',
})
export class MinePage {
  
  constructor(public navCtrl: NavController,public modalCtrl: ModalController, public navParams: NavParams) {
  }
  opensetting(){
      this.navCtrl.push(SettingsPage);
    }
  ionViewDidLoad() {
    

}
}
